title: TensorFlow 2.0 教程
date: '2019-09-03 11:26:58'
updated: '2019-09-03 11:27:03'
tags: [TensorFlow]
permalink: /articles/2019/09/03/1567481218319.html
---
最全 TensorFlow2.0 教程-持续更新
原文地址：https://blog.csdn.net/qq_31456593/article/details/88606284

最新tensorflow2教程和相关资源，请关注微信公众号：DoitNLP， 后面我会在DoitNLP上，持续更新深度学习、NLP、Tensorflow的相关教程和前沿资讯，它将成为我们一起学习tensorflow2的大本营

本教程主要由tensorflow2.0官方教程的个人学习复现笔记整理而来，并借鉴了一些keras构造神经网络的方法，中文讲解，方便喜欢阅读中文教程的朋友，tensorflow官方教程：https://www.tensorflow.org

Tensorflow2.0 教程持续更新：

TensorFlow 2.0 教程- Keras 快速入门
TensorFlow 2.0 教程-keras 函数api
TensorFlow 2.0 教程-使用keras训练模型
TensorFlow 2.0 教程-用keras构建自己的网络层
TensorFlow 2.0 教程-keras模型保存和序列化
TensorFlow 2.0 教程-eager模式
TensorFlow 2.0 教程-Variables
TensorFlow 2.0 教程–AutoGraph

TensorFlow 2.0 深度学习实践

TensorFlow2.0 教程-图像分类
TensorFlow2.0 教程-文本分类
TensorFlow2.0 教程-过拟合和欠拟合
TensorFlow2.0教程-结构化数据分类
TensorFlow2.0教程-回归
TensorFlow2.0教程-保持和读取模型

TensorFlow 2.0 基础网络结构

TensorFlow2教程-基础MLP网络
TensorFlow2教程-mlp及深度学习常见技巧合
TensorFlow2教程-基础CNN网络
TensorFlow2教程-CNN变体网络
TensorFlow2教程-文本卷积
TensorFlow2教程-使用预训练CNN模型
TensorFlow2教程-LSTM和GRU
TensorFlow2教程-自编码器
TensorFlow2教程-卷积自编码器
TensorFlow2教程-词嵌入
TensorFlow2教程-DCGAN
TensorFlow2教程-使用Estimator构建Boosted trees
TensorFlow2教程-RNN文本分类
TensorFlow2教程-Transformer

TensorFlow 2.0 eager模式

TensorFlow2.0教程-张量极其操作
TensorFlow2.0教程-自定义层
TensorFlow2.0教程-自动求导
TensorFlow2.0教程-使用低级api训练(非tf.keras)
TensorFlow2.0教程-自定义训练实战(非tf.keras)
TensorFlow2教程-TF fuction和AutoGraph

TensorFlow 2.0 安装

TensorFlow2 教程-Ubuntu安装TensorFlow 2.0
TensorFlow2教程-Windows安装tensorflow2.0

代码实现：

完整tensorflow2.0教程代码请看tensorflow2.0：中文教程tensorflow2_tutorials_chinese(欢迎star)

更多TensorFlow2.0 入门教程请持续关注本博客：https://blog.csdn.net/qq_31456593/article/details/88606284
本博客每周都会更新最新的tensorflow2的教程

关键词：TensorFlow 2.0 入门 教程 代码 实践
————————————————
版权声明：本文为CSDN博主「Doit_」的原创文章，遵循 CC 4.0 BY-SA 版权协议，转载请附上原文出处链接及本声明。
原文链接：https://blog.csdn.net/qq_31456593/article/details/88606284
